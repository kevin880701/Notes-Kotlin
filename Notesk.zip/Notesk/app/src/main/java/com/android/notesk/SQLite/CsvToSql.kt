package com.android.notesk.SQLite

import android.content.Context
import android.util.Log
import com.android.notesk.Model.Model.Companion.PACKAGE_FILES_PATH
import com.android.notesk.Model.Model.Companion.csvBackUp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.BufferedReader
import java.io.File
import java.io.FileReader

class CsvToSql {
    var dataBase : NotesDatabase
    val filepath = PACKAGE_FILES_PATH + File.separator + csvBackUp
    var linePosition = 0
    constructor(mContext : Context,state : Boolean) {
        dataBase = NotesDatabase(mContext)

        try {
            val file = FileReader(filepath)
            val buffer = BufferedReader(file)
            var line : String? = ""

            while (buffer.readLine().also({line = it}) != null) {
                var str = (line as String).split(",".toRegex(), 4)
                var notesEntity = NotesEntity()

                Log.v("PPP","" + str[0])
                Log.v("PPP","" + str[1])
                Log.v("PPP","" + str[2])
                Log.v("PPP","" + str[3])
//                Log.v("PPP","INDEX：" + str[3].indexOf("\n"))

                if(linePosition > 0){
                    if(state){
                        notesEntity.id = str[0].toInt()
                    }
                    notesEntity.title = str[1]
                    notesEntity.content = str[2]
                    notesEntity.picPath = str[3]


                    runBlocking {     // 阻塞主執行緒
                        launch(Dispatchers.IO) {
                            dataBase.getNotesDao().insert(notesEntity)
                        }
                    }
                }
                linePosition++
            }
        }catch (e : Exception) {
            Log.e("CsvToSqlError","" + e)
        }
    }
}
