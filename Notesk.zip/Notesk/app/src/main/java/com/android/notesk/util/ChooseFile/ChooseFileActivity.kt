package com.android.notesk.util.ChooseFile

import android.accounts.AccountManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.notesk.Model.Model.Companion.ACCOUNT_CHOOSE
import com.android.notesk.Model.Model.Companion.DATABASES_PATH
import com.android.notesk.Model.Model.Companion.GOOGLE_SIGN_IN
import com.android.notesk.Model.Model.Companion.KEEP_FILE
import com.android.notesk.Model.Model.Companion.OVER_FILE
import com.android.notesk.Model.Model.Companion.PACKAGE_FILES_PATH
import com.android.notesk.Model.MyAdapter
import com.android.notesk.R
import com.android.notesk.SQLite.CsvToSql
import com.android.notesk.SQLite.NotesEntity
import com.android.notesk.Zip.UnZip
import com.facebook.stetho.Stetho
import kotlinx.android.synthetic.main.activity_choose_file.*
import java.io.File


class ChooseFileActivity : AppCompatActivity(), View.OnClickListener {


    lateinit var presenter : ChooseFilePresenter
    lateinit var adapter : MyAdapter

    companion object {
        var allList : ArrayList<NotesEntity> = ArrayList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(R.layout.activity_choose_file)
        Stetho.initializeWithDefaults(this)

        presenter = ChooseFilePresenter(this)
        adapter = MyAdapter(presenter)

        recyclerView.setLayoutManager(LinearLayoutManager(this))
        recyclerView.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        recyclerView.setAdapter(adapter)
        presenter.selectSql(adapter)
        DATABASES_PATH = this.getCacheDir().parent + "/databases"
        add.setOnClickListener(this)
        presenter.createNavigationView()
        menu.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.add -> {
                presenter.editFilePage(null)
            }
            R.id.menu -> { // 側滑選單
                drawerLayout.openDrawer(GravityCompat.START)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
        super.onActivityResult(requestCode, resultCode, intent)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                ACCOUNT_CHOOSE -> {
//                    Log.v("777","1111" + intent?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME))
                    presenter.signAccount(intent?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME))
//                    presenter.handleSignInResult(intent as Intent)
                }
                GOOGLE_SIGN_IN -> {
//                    Log.v("777","1111" + intent?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME))
                    presenter.handleSignInResult(intent as Intent)
                }
                OVER_FILE -> {
                    presenter.delTable()

                    var uri = intent?.data as Uri
                    UnZip().unzip(uri, PACKAGE_FILES_PATH + File.separator, this)
                    CsvToSql(this, true)
                    presenter.selectSql(adapter)
//                    try {   //將備份檔複製出來
//                        var byteread = 0
//                        val inStream: InputStream = this.getContentResolver().openInputStream(uri) as InputStream//讀取
//                        val fs = FileOutputStream(PACKAGE_FILES_PATH + File.separator + BACKUP_NAME) //輸出
//                        val buffer = ByteArray(1444)
//                        while (inStream.read(buffer).also { byteread = it } != -1) {
//                            fs.write(buffer, 0, byteread)
//                        }
//                        inStream.close()
//                    } catch (e: Exception) {
//                        Log.v("ERROR", "" + e)
//                    }
                }
                KEEP_FILE -> {
                    var uri = intent?.data as Uri
                    UnZip().unzip(uri, PACKAGE_FILES_PATH + File.separator, this)
                    CsvToSql(this, false)
                    presenter.selectSql(adapter)
                }
            }
        }
    }
}
