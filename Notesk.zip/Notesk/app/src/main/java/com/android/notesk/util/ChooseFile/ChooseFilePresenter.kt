package com.android.notesk.util.ChooseFile

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat.startActivityForResult
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import com.android.notesk.GoogleDriver.DriveServiceHelper
import com.android.notesk.Model.Model
import com.android.notesk.Model.Model.Companion.ACCOUNT_CHOOSE
import com.android.notesk.Model.Model.Companion.GOOGLE_SIGN_IN
import com.android.notesk.Model.MyAdapter
import com.android.notesk.R
import com.android.notesk.SQLite.NotesDatabase
import com.android.notesk.SQLite.NotesEntity
import com.android.notesk.SQLite.SqlToCsv
import com.android.notesk.Zip.ZipUtils
import com.android.notesk.util.ChooseFile.BackupChoose.BackupChoosePopupWindow
import com.android.notesk.util.EditFile.EditFileActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.AccountPicker
import com.google.android.gms.common.api.Scope
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import kotlinx.android.synthetic.main.activity_choose_file.*
import kotlinx.coroutines.*
import java.io.File
import java.util.*
import kotlin.collections.ArrayList


class ChooseFilePresenter(context : ChooseFileActivity) {
    val mContext = context
    var allList : ArrayList<NotesEntity> = ArrayList<NotesEntity>()
    val dataBase = NotesDatabase(context)

    fun selectSql(adapter : MyAdapter){
        GlobalScope.launch(Dispatchers.IO) {
            allList = dataBase.getNotesDao().getAll() as ArrayList<NotesEntity>
            withContext(Dispatchers.Main){
                adapter.update(allList)
            }
        }
    }

    fun delTable(){
        runBlocking {     // 阻塞主執行緒
            launch(Dispatchers.IO) {
                dataBase.getNotesDao().deletTable()
            }
        }
    }

    fun picGone(notesEntity: NotesEntity){
        GlobalScope.launch {
            dataBase.getNotesDao().insert(notesEntity)
        }
    }

    fun syncClick(){
        val intent = AccountPicker.newChooseAccountIntent(
            null, null, arrayOf("com.google"),
            true, null, null, null, null
        )
        startActivityForResult(mContext,intent, ACCOUNT_CHOOSE,null)
    }

    fun signAccount(account: String?){
        try {
            val signInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(
                    Scope(DriveScopes.DRIVE_FILE),
                    Scope(DriveScopes.DRIVE_APPDATA)
                ).setAccountName(account)
                .requestIdToken("1072640924634-58t06k8q3g9umanh3fajvf5s3drim4q5.apps.googleusercontent.com")
                .build()
            val client = GoogleSignIn.getClient(mContext, signInOptions)

            startActivityForResult(mContext, client.signInIntent, GOOGLE_SIGN_IN, null)
        }catch (e:java.lang.Exception){
            Log.v("ERROR：",e.toString() )
        }
    }

    fun handleSignInResult(result: Intent) {
        Log.v("777","1111")
        GoogleSignIn.getSignedInAccountFromIntent(result)
            .addOnSuccessListener { googleAccount: GoogleSignInAccount ->
                Log.d(TAG, "Signed in as " + googleAccount.email)
                val credential = GoogleAccountCredential.usingOAuth2(mContext, Collections.singleton(DriveScopes.DRIVE_FILE))
                credential.selectedAccount = googleAccount.account
                val googleDriveService = Drive.Builder(
                    AndroidHttp.newCompatibleTransport(),
                    GsonFactory(),
                    credential
                ).setApplicationName("Notes")
                    .build()
                // The DriveServiceHelper encapsulates all REST API and SAF functionality.
                // Its instantiation is required before handling any onClick actions.
//                val openOptions = OpenFileActivityOptions.Builder()
//                    .setSelectionFilter(
//                        Filters.not(Filters.eq(SearchableField.MIME_TYPE, DriveFolder.MIME_TYPE))
//                    )
//                    .setActivityTitle("HELLO")
//                    .build()

                var mDriveServiceHelper = DriveServiceHelper(googleDriveService)
//                mDriveServiceHelper.createFolder()
//                mDriveServiceHelper.searchFile()
//                zipFile()
//                mDriveServiceHelper.test(mContext,googleAccount)
                mDriveServiceHelper.tt(mContext,googleAccount)
            }
            .addOnFailureListener { exception: Exception? ->
                Log.e(TAG,"Unable to sign in.",exception)
            }
    }

//    fun pickItem(openOptions: OpenFileActivityOptions): Task<DriveId?>? {
//        var mOpenItemTaskSource = TaskCompletionSource<Any>()
//        getDriveClient(mContext,googleAccount)
//            .newOpenFileActivityIntentSender(openOptions)
//            .continueWith(Continuation<IntentSender, Void> { task ->
//                startIntentSenderForResult(mContext,
//                    task.getResult() as IntentSender, REQUEST_CODE_OPEN_ITEM, null, 0, 0, 0)
//                null
//            } as Continuation<IntentSender?, Void?>?)
//        return mOpenItemTaskSource.getTask()
//    }

    fun editFilePage(notesEntity: NotesEntity?){
        val intent = Intent(mContext, EditFileActivity::class.java)
        notesEntity?.let {
            val bundle = Bundle()
            bundle.putSerializable("notesEntity", notesEntity)
            intent.putExtras(bundle)
        }
        mContext.startActivity(intent)
        mContext.finish()
    }

    fun createNavigationView(){
        mContext.navigationView.setNavigationItemSelectedListener(object :
            NavigationView.OnNavigationItemSelectedListener {
            override fun onNavigationItemSelected(item: MenuItem): Boolean {
                // 點選時收起選單
                mContext.drawerLayout.closeDrawer(GravityCompat.START)
                // 取得選項id
                val id: Int = item.getItemId()
                // 依照id判斷點了哪個項目並做相應事件
                when (id) {
                    R.id.overFile -> {
                        Toast.makeText(mContext,mContext.getString(R.string.upload), Toast.LENGTH_SHORT).show()
                        SqlToCsv(mContext)
                        ZipUtils()  //製作備份檔
                        var shareIntent = Intent(Intent.ACTION_SEND)
                        val backupUri = FileProvider.getUriForFile(
                            mContext,
                            mContext.packageName + ".provider",
                            File(File(Model.PACKAGE_FILES_PATH).parent + File.separator + Model.BACKUP_NAME)
                        )
                        shareIntent.putExtra(Intent.EXTRA_STREAM,backupUri)
                        shareIntent.setType("*/*")
                        mContext.startActivity(shareIntent)
                        return true
                    }
                    R.id.restore -> {
                        val choose = BackupChoosePopupWindow(mContext,this@ChooseFilePresenter)
                        val view: View = LayoutInflater.from(mContext).inflate(R.layout.popup_window_pic_change, null)
                        choose.showAtLocation(view, Gravity.CENTER, 0, 0)
                    }
                }
                return false
            }
        })
    }

    fun chooseBackup(requestCode:Int){
        val picker = Intent(Intent.ACTION_GET_CONTENT)
        picker.type = "*/*"
        startActivityForResult(mContext,picker,requestCode,null)
    }
}
